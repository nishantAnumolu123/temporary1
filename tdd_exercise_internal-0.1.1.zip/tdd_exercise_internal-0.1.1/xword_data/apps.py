from django.apps import AppConfig


class XwordDataConfig(AppConfig):
    name = 'xword_data'
